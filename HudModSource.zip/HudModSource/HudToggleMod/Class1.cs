﻿using MelonLoader;
using UnityEngine;



[assembly: MelonInfo(typeof(HudToggle), "HudToggleMod", "1.0.0", "sb & Wispp")]
[assembly: MelonGame("Mash Games", "Mash Box")]

public class HudToggle : MelonMod
{
    private bool menuOpen = false;

    GameObject activityDisplay; 
    GameObject DDClone; 

    public override void OnGUI()
    {
        if (menuOpen)
        {
            Cursor.visible = true;
            if (GUI.Button(new Rect(25f, 70f + 100f, 100f, 30f), "Enable HUD"))
            {
                if (activityDisplay != null && DDClone != null)
                {
                    activityDisplay.SetActive(true);
                    DDClone.SetActive(true);
                }
            }

            if (GUI.Button(new Rect(25f, 110f + 100f, 100f, 30f), "Hide HUD"))
            {
                if (GameObject.Find("Activity Display") != null && GameObject.Find("DD(Clone)") != null)
                {
                    activityDisplay = GameObject.Find("Activity Display"); // Trick Analyzer
                    activityDisplay.SetActive(false);
                    DDClone = GameObject.Find("DD(Clone)"); //Donate Button
                    DDClone.SetActive(false);
                }
            }
        }
    }

    public override void OnUpdate()
    {
        if (Input.GetKeyDown(KeyCode.H))
        {
            menuOpen = !menuOpen;
        }
    }
}